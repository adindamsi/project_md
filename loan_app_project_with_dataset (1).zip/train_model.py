
import pandas as pd
import pickle
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report

class LoanModelTrainer:
    def __init__(self, data_path):
        self.data_path = data_path
        self.model = RandomForestClassifier(n_estimators=100, random_state=42)
        self.label_encoders = {}

    def load_data(self):
        df = pd.read_csv(self.data_path)
        df.dropna(inplace=True)
        return df

    def preprocess_data(self, df):
        categorical_cols = ['person_gender', 'person_education',
                            'person_home_ownership', 'loan_intent',
                            'previous_loan_defaults_on_file']
        for col in categorical_cols:
            le = LabelEncoder()
            df[col] = le.fit_transform(df[col])
            self.label_encoders[col] = le

        X = df.drop("loan_status", axis=1)
        y = df["loan_status"]
        return train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    def train_model(self, X_train, y_train):
        self.model.fit(X_train, y_train)

    def evaluate_model(self, X_test, y_test):
        y_pred = self.model.predict(X_test)
        print("Classification Report:\n", classification_report(y_test, y_pred))

    def save_model(self, output_path="rf_model.pkl"):
        with open(output_path, "wb") as f:
            pickle.dump(self.model, f)
        print(f"Model saved to {output_path}")

    def run_all(self):
        df = self.load_data()
        X_train, X_test, y_train, y_test = self.preprocess_data(df)
        self.train_model(X_train, y_train)
        self.evaluate_model(X_test, y_test)
        self.save_model()

if __name__ == "__main__":
    trainer = LoanModelTrainer(data_path="Dataset_A_loan.csv")
    trainer.run_all()
