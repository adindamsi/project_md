# Loan Approval Predictor 🚀

This project is part of the UTS for DTSC6012001 (Model Deployment). It includes training a Random Forest model to predict loan approval and deploying the model using Streamlit.

## 📁 Files

- `app.py`: Streamlit web app interface.
- `random_forest.pkl`: Trained machine learning model.
- `train_model.py`: Script for training the Random Forest model using OOP.
- `inference.py`: Simple script to test the model inference manually.
- `Dataset_A_loan.csv`: Dataset used for training (optional for deploy).
- `requirements.txt`: Required Python libraries.

## 📦 Installation

Install required packages:

```bash
pip install -r requirements.txt
```

## 🚀 Run Locally

```bash
streamlit run app.py
```

## 🌐 Deployment

You can deploy this project to [Streamlit Cloud](https://streamlit.io/cloud).

## 👨‍🎓 Author

Created by [Your Name] for DTSC6012001 UTS.